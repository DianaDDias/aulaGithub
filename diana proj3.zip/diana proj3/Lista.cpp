#include "Lista.h"
#include "Book.h"
#include<iostream>
#include<cstring>
using namespace std;

Lista::Lista()
{
    inicio = 0;
    fim = 0;
    tamanho_lista = 0;
}
Lista::~Lista()
{
    Book* aux = inicio;
    while(aux)
    {
        inicio = inicio->get_prox();
        delete aux;
        aux = inicio;
    }
}
int Lista::get_tamanho()
{
    return tamanho_lista;
}
void Lista::insere_fim(Book* b)
{
    if(vazia())
    {
        inicio = b;
        fim = b;
    }
    else
    {
        fim->set_prox(b);
        fim = b;
    }
    tamanho_lista++;
}

bool Lista::vazia()
{
    return inicio == 0;
}
void Lista::imprime()
{
    if(vazia()) cout << "Lista vazia!";
    else
    {
        Book* atual = inicio;
        cout << "#" << tamanho_lista << ": ";
        while(atual)
        {
            cout << atual->get_ISBN() << " ";
            atual = atual->get_prox();
            if(atual){
                cout << " | ";
            }
        }
    }
}
Book* Lista::procura(char* str)
{
    Book* aux = inicio;
    while(aux){
        if(strcmp(aux->get_ISBN(),str)==0)
            return aux;
        aux = aux->get_prox();
    }
    return 0;
}
