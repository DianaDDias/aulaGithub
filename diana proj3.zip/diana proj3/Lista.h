#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include "Book.h"
using namespace std;

class Lista
{
private:
    Book *inicio;
    Book *fim;
    int tamanho_lista;
public:
    Lista();
    ~Lista();
    int get_tamanho();
    void insere_fim(Book* p);
    bool vazia();
    void imprime();
    Book* procura(char* str);
};

#endif // LISTA_H_INCLUDED
