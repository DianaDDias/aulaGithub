#include "Hashing.h"
#include <iostream>
#include <cstring>

using namespace std;

Hashing::Hashing(int _tam) {
    tamanho_tabela = _tam;
      vet = new Lista*[tamanho_tabela]; // Aloca um array de ponteiros para Lista

    // Inicializa cada posi��o do array com um novo objeto Lista
    for (int i = 0; i < tamanho_tabela; i++) {
        vet[i] = new Lista();
    }

    quant_colisoes = 0;
}
Hashing::~Hashing() {
    for (int i = 0; i < tamanho_tabela; i++) {
        vet[i];  // Destr�i a lista encadeada

    delete vet[i];
    }
}

int Hashing::f(const char* str) {
    const double A = 0.6180339887; // Constante �urea
    const int w = sizeof(int) * 8; // Tamanho em bits de um inteiro
    const int z = w / 2; // N�mero de bits menos significativos a considerar

    unsigned long hash = 0;
    while (*str) {
        hash = hash * 31 + tolower(*str);
        str++;
    }

    // M�todo da multiplica��o
    double t = A * hash;
    t = t - (int)t;
    int index = (int)(t * tamanho_tabela);

    return index;
}
void Hashing::insere(Book* b) {
    int indice = f(b->get_ISBN());

    // Verifica se j� existe algum elemento no bucket
    if (!vet[indice]->vazia()) {
        quant_colisoes++;
    }

    vet[indice]->insere_fim(b);
}
void Hashing::imprime() {
    for (int i = 0; i < tamanho_tabela; i++) {
        cout << "Bucket " << i << ": ";
        vet[i]->imprime();
    }
}
int Hashing::get_quantColisoes() {
    return quant_colisoes;
}
void Hashing::consulta( char* isbn) {
    int indice = f(isbn);

    if (indice >= 0 && indice < tamanho_tabela) {
        Lista* lista = vet[indice]; // Obt�m a lista no �ndice calculado
        Book* livro = lista->procura(isbn); // Utiliza o m�todo procura da lista

        if (livro != nullptr) {
            cout << "Livro encontrado: " << endl;
            livro->print();
        } else {
            cout << "Livro n�o encontrado." << endl;
        }
    } else {
        cout << "�ndice inv�lido." << endl;
    }
}
